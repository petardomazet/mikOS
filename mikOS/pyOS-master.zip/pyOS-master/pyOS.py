from kernel.system import System

if __name__ == '__main__':
    System.run()